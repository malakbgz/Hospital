const DoctorDetails = () => {
  return (
    <div>DoctorDetails</div>
  )
}
export default DoctorDetails